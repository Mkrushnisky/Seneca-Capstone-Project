﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
// new...
using AutoMapper;

namespace BTPProject
{
    public static class AutoMapperConfig
    {
        public static void RegisterMappings()
        {
            // Add map creation statements here
            // Mapper.CreateMap< FROM , TO >();
            Mapper.CreateMap<Models.supplier, Controllers.SupplierAdd>();
            Mapper.CreateMap<Models.supplier, Controllers.SupplierBase>();
            Mapper.CreateMap<Models.supplier, Controllers.SupplierWithDetail>();
            Mapper.CreateMap<Controllers.SupplierAdd, Models.supplier>();
            Mapper.CreateMap<Controllers.SupplierBase, Models.supplier>();
            Mapper.CreateMap<Controllers.SupplierBase, Controllers.SupplierWithDetail>();
            Mapper.CreateMap<Controllers.SupplierBase, Controllers.SupplierEditForm>();
            Mapper.CreateMap<Controllers.SupplierBase, Controllers.SupplierEditForm>();

        }
    }
}