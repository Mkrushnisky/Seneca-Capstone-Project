﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
// new...
using AutoMapper;
using BTPProject.Models;

namespace BTPProject.Controllers
{
    public class Manager
    {
        // Reference to the data context
        private btsdatabaseEntities ds = new btsdatabaseEntities();

        public Manager()
        {
            // If necessary, add constructor code here
        }

        public IEnumerable<SupplierBase> SupplierGetAll()
        {
            return Mapper.Map<IEnumerable<SupplierBase>>(ds.suppliers.OrderBy(c => c.SupName));
        }

        public SupplierBase SupplierGetById(int Id)
        {
            var o = ds.suppliers.Find(Id);
            return (o == null) ? null : Mapper.Map<SupplierBase>(o);
        }

        public SupplierBase SupplierAddNew(SupplierAdd newItem)
        {
            var addItem = ds.suppliers.Add(new supplier
            {
                SupName = newItem.SupName,
                WebLink = newItem.WebLink
            });
            ds.SaveChanges();
            return (addItem == null) ? null : Mapper.Map<SupplierBase>(addItem);
        }

        public SupplierBase SupplierEdit(SupplierEdit newItem)
        {
            var o = ds.suppliers.Find(newItem.Id);
            if (o == null)
            {
                return null;
            }
            else
            {
                ds.Entry(o).CurrentValues.SetValues(newItem);
                ds.SaveChanges();
                return Mapper.Map<SupplierBase>(o);
            }
        }

        public bool SupplierDelete(int Id)
        {
            var itemtodelete = ds.suppliers.Find(Id);
            if (itemtodelete == null)
            {
                return false;
            }
            else
            {
                ds.suppliers.Remove(itemtodelete);
                ds.SaveChanges();

                return true;
            }
        }
    }
}