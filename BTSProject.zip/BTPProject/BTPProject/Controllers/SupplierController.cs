﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BTPProject.Controllers;

namespace BTPProject.Controllers
{
    public class SupplierController : Controller
    {
        Manager m = new Manager();

        // GET: Supplier
        public ActionResult Index()
        {
            return View(m.SupplierGetAll());
        }

        // GET: Supplier/Details/5
        public ActionResult Details(int? id)
        {
            var o = m.SupplierGetById(id.GetValueOrDefault());

            if (o == null)
            {
                return HttpNotFound();
            }
            else
            {
                return View(o);
            }
        }

        // GET: Supplier/Create
        public ActionResult Create()
        {
            var form = new SupplierAddForm();
            return View(form);
        }

        // POST: Supplier/Create
        [HttpPost]
        public ActionResult Create(SupplierAdd newItem)
        {
            if (!ModelState.IsValid)
            {
                return View(newItem);
            }
            var addItem = m.SupplierAddNew(newItem);
            if (addItem == null)
            {
                return View(newItem);
            }
            else
            {
                return RedirectToAction("Details", new { id = addItem.Id });
            }
        }

        // GET: Supplier/Edit/5
        public ActionResult Edit(int? id)
        {
            var o = m.SupplierGetById(id.GetValueOrDefault());
            if(o == null)
            {
                return HttpNotFound();
            }
            else
            {
                var editform = AutoMapper.Mapper.Map<SupplierEditForm>(o);
                return View(editform);
            }
        }

        // POST: Supplier/Edit/5
        [HttpPost]
        public ActionResult Edit(int? id, SupplierEdit newItem)
        {
            
            if (!ModelState.IsValid)
            {
                return RedirectToAction("edit", new { id = newItem.Id });
            }
            if (id.GetValueOrDefault() != newItem.Id)
            {
                return RedirectToAction("index");
            }

            var editedItem = m.SupplierEdit(newItem);

            if (editedItem == null)
            {
                return RedirectToAction("edit", new { id = newItem.Id });
            }
            else
            {
                return RedirectToAction("details", new { id = newItem.Id });
            }
        }

        // GET: Supplier/Delete/5
        public ActionResult Delete(int? Id)
        {
            var itemtodelete = m.SupplierGetById(Id.GetValueOrDefault());
            if (itemtodelete == null)
            {
                return RedirectToAction("index");
            }
            else
            {
                return View(itemtodelete);
            }
        }

        // POST: Supplier/Delete/5
        [HttpPost]
        public ActionResult Delete(int? Id, FormCollection collection)
        {
            var results = m.SupplierDelete(Id.GetValueOrDefault());
            return RedirectToAction("index");
        }
    }
}
