﻿using System;
using System.Web;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using BTPProject.Models;

namespace BTPProject.Controllers
{
    public class SupplierAdd
    {
        public SupplierAdd()
        {

        }
        public string SupName { get; set; }
        public string WebLink { get; set; }
    }

    public class SupplierAddForm : SupplierAdd
    {

    }

    public class SupplierBase : SupplierAdd
    {
        public SupplierBase()
        {

        }
        [Key]
        public int Id { get; set; }
    }

    public class SupplierWithDetail : SupplierBase
    {
        public SupplierWithDetail()
        {
        }
    }
    public class SupplierEditForm
    {
        public int Id { get; set; }
        [Required]
        [StringLength(200)]
        public string SupName { get; set; }
        [Required]
        [StringLength(200)]
        public string WebLink { get; set; }
    }
    public class SupplierEdit
    {
        public SupplierEdit()
        {

        }
        public int Id { get; set; }
        public string SupName { get; set; }
        public string WebLink { get; set; }
        }
    }
